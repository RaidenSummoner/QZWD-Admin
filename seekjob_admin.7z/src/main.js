import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import Framework from '@/components/Framework.vue'
import Sidebar from '@/components/Sidebar.vue'
Vue.use(ElementUI);
Vue.component('Framework',Framework);
Vue.component('Sidebar',Sidebar);
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

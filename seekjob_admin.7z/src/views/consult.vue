<template>
    <div>
    
    <div class="topbutton">
      <div>
      <!-- <el-input v-model="tableDatapid" size="small" placeholder="请输入姓名" style="width:240px"></el-input>
      <el-button type="primary" size="small" @click="searchUser">搜索</el-button> -->
      <!-- <el-button type="primary" size="small" @click="openData">展示数据</el-button> -->
      <el-button type="success" size="small" @click="addRow(users)">新增</el-button>
      <!-- <el-button type="success" size="small" @click="handleAdd()">新增</el-button> -->
      <el-button type="primary" size="small" @click="removeUsers()">取消发布</el-button>
      <el-button type="primary" size="small" >一键发布<i class="el-icon-upload el-icon--right"></i></el-button>
    </div>
      <el-table :data="users" highlight-current-row v-loading="listLoading" @selection-change="selsChange" style="width: 100%;">
          <el-table-column type="selection" width="60">
          </el-table-column>
          <el-table-column prop="pid"  label="内容编号" width="120" sortable>
          </el-table-column>
          <el-table-column prop="title" label="课程标题" width="100">
          </el-table-column>
          <el-table-column prop="status" label="发布状态" min-width="120">
          </el-table-column>
          <el-table-column prop="category" label="咨询类目" min-width="120">
          </el-table-column>
          <el-table-column prop="date" label="日期" min-width="180" sortable>
          </el-table-column>
          <el-table-column label="操作" width="300">
            <template slot-scope="scope">
              <!-- <el-button type="success" size="small" @click="handleEdit(scope.$index, scope.row)">新增</el-button> -->
              <el-button type="primary" size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
              <el-button size="small" type="danger" @click="handleDelete(scope.$index, users)">删除</el-button>
              <el-button size="small"               @click="msgPreviewTester">预览</el-button>
              <el-button size="small"               @click="msgPublishTester">发布</el-button>
            </template>
          </el-table-column>
      </el-table> 
    </div>
        <!--新增/编辑界面-->
    <el-dialog :title="titleMap[dialogStatus]" :visible.sync="FormVisible" :close-on-click-modal="false" class="edit-form"
    :before-close="handleClose">
      <el-form :model="Form" label-width="80px" :rules="editFormRules" ref="Form">
          <el-form-item label="课程标题" prop="title" >
            <el-input v-model="Form.title" auto-complete="off"></el-input>
          </el-form-item>
          <el-form-item label="商品价格">
            <el-input-number v-model="Form.title"></el-input-number>
          </el-form-item>
          <el-form-item label="商品库存">
            <el-input v-model="Form.status"></el-input>
          </el-form-item>
          <el-form-item label="正文内容">
            <el-input type="textarea" v-model="Form.desc"></el-input>
          </el-form-item>         
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click.native="handleCancel('Form')">取消</el-button>
          <el-button v-if="addBtnshow" type="primary" @click.native="confirmAdd('Form')">确定</el-button>
          <el-button v-if="editBtnshow" type="primary" @click.native="confirmEdit('Form')">确定</el-button>
        </div>
      </el-dialog>      
  </div>
</template>
<script>
  var _index;
  export default {
    data() {
      return {
        pickerOptions: {
          disabledDate(time) {
            return time.getTime() > Date.now();
          }
        },
        titleMap: {
            addEquipment:'新增',
            editEquipment: "编辑"
        },
                 //新增和编辑弹框标题
        dialogStatus: "",
        Form: {
		  id: 0,
		  pid: '',
		  title: 0,
          status:'',
          data: '',
          desc: '',      
        },
        users:[
        {pid:'001',title:'一本学姐',status:'草稿',category:'产品-案例分享',date:'2016-05-01'},
        {pid:'002',title:'二本学姐',status:'已发布',category:'产品-案例分享',date:'2016-05-02'},
        {pid:'003',title:'三本学姐',status:'草稿',category:'产品-案例分享',date:'2016-05-02'},
        {pid:'004',title:'四本学姐',status:'草稿',category:'产品-案例分享',date:'2016-05-04'},
        {pid:'005',title:'五本学姐',status:'草稿',category:'产品-案例分享',date:'2016-05-05'}
        ],  
        editFormRules:{
          pid: [
            { required: true, message: '请输入商品名称', trigger: 'blur' }
          ],
          status: [
            { required: true, message: '请输入商品库存', trigger: 'blur' }
          ],
          desc: [
            { required: true, message: '请输入商品描述', trigger: 'blur' }
          ],
        },
        FormVisible: false,
        currentRow:[],
        ids:[],
        listLoading:'',
        addBtnshow:false,
        editBtnshow:false,
        editLoading:'', 
        dialogStatus: '',
        selected:[],
        editid:'',
        searchForm:[]
      }
    },
    methods: {
      selsChange:function(val){  //点击选中
        console.log(val);
        this.selected = val;
      },
      msgPreviewTester() {
        this.$message('预览了~death~');
      },
      msgPublishTester() {
        this.$message('发布了~death~');
        this.status="已发布";
      },
      addRow(users,event) {
        this.FormVisible = true;
        this.Form = {
          id: 0,
          pid: '',
          title: 0,
          status:'',
          data:'',
          desc: '',
        };
        this.dialogStatus = "addEquipment"
        this.addBtnshow = true
        this.editBtnshow = false
      },
      // 点击确定（新增）
      confirmAdd() { 
        // this.users = this.users || []
        this.users.push({
        pid: this.Form.pid,
        title: this.Form.title,
        status: this.Form.status,
        data: this.Form.data,
        desc: this.Form.desc
      })
      // storage.set('users', this.users);
      this.FormVisible = false;      
      },
      //点击编辑
      handleEdit:function(index, row) {
        this.FormVisible = true;
        this.Form = Object.assign({}, row); //这句是关键！！！
        _index = index;
        console.log(index);
        console.log(_index);
        
        this.dialogStatus = "editEquipment"
        this.addBtnshow = false
        this.editBtnshow = true
      },   
      // 点击确定（编辑）  
      confirmEdit(){
        var editdata = _index;
        console.log(editdata);
        this.users[editdata].pid=this.Form.pid;
        this.users[editdata].title=this.Form.title;
        this.users[editdata].status=this.Form.status;
        this.users[editdata].data=this.Form.data;
        this.users[editdata].desc=this.Form.desc;
        this.FormVisible = false;
            },
      //点击关闭dialog
      handleClose(done) {
        //  done();
        //  location.reload();
        this.FormVisible = false;
      },     
      //点击取消
      handleCancel(formpid) {
        this.FormVisible = false;
      },
      // 删除   
      handleDelete(index, row) {
        console.log(index, row);
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            // delete:row.splice(index, 1),
            type: 'success',
            message: '删除成功!',
            delete: row.splice(index, 1)   //splice 删除对象是数unfuntion组   如果是对象会出现错误  row.solice not is
 
            // url: this.$router.push('/')
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
      },
      removeUsers() {
          this.$confirm('此操作将永久删除 ' + this.selected.length + ' 个用户, 是否继续?', '提示', { type: 'warning' })
          .then(() => {
          console.log(this.selected);
          var ids = [];
          //提取选中项的id
          $.each(this.selected,(i, users)=> {
          ids.push(users.id);
          });
          // 向请求服务端删除
          //  var resource = this.$resource(this.url);
          resource.remove({ids: ids.join(",") })
          .then((response) => {
          this.$message.success('删除了' + this.selected.length + '个用户!');
          this.getUsers();
          })
          .catch((response) => {
          this.$message.error('删除失败!');
          });
          })
          .catch(() => {
          this.$Message('已取消操作!');
          });
      }     
    }, 
  }
</script>
<style>
.el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 160px;
  }
  .el-table{
    background-color: #E9EEF3;
    
    color: #333;
  }
  .topbutton{
    position:relative;
    z-index:999; top:0;
  }
</style>